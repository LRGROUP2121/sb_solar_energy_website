<?php
session_start(); require_once __DIR__."/../config/database.php";
if(isset($_SESSION["admin_id"])){header("Location:index.php");exit;}
$error="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
 $q=$pdo->prepare("SELECT * FROM admins WHERE email=? LIMIT 1");$q->execute([trim($_POST["email"]??"")]);$a=$q->fetch();
 if($a && password_verify($_POST["password"]??"",$a["password"])){session_regenerate_id(true);$_SESSION["admin_id"]=$a["id"];header("Location:index.php");exit;}
 $error="Invalid login.";
}
?><!doctype html><html><body style="font-family:Arial;background:#f4f6f8"><div style="max-width:380px;margin:100px auto;background:white;padding:30px;border-radius:12px"><h2>☀️ SB SOLAR ENERGY</h2><p>Admin Login</p><p style="color:red"><?=htmlspecialchars($error)?></p><form method="post"><input style="width:100%;padding:12px;box-sizing:border-box" name="email" type="email" placeholder="Email" required><br><br><input style="width:100%;padding:12px;box-sizing:border-box" name="password" type="password" placeholder="Password" required><br><br><button style="width:100%;padding:12px" type="submit">Login</button></form></div></body></html>
