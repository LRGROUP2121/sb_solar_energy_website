<?php
function sendWhatsAppText($to,$body){
 $c=require __DIR__."/../config/config.php";
 $url="https://graph.facebook.com/".$c["whatsapp"]["api_version"]."/".$c["whatsapp"]["phone_number_id"]."/messages";
 $data=["messaging_product"=>"whatsapp","to"=>$to,"type"=>"text","text"=>["preview_url"=>false,"body"=>$body]];
 $ch=curl_init($url);
 curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($data,JSON_UNESCAPED_UNICODE),
 CURLOPT_HTTPHEADER=>["Authorization: Bearer ".$c["whatsapp"]["token"],"Content-Type: application/json"],
 CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30]);
 $r=curl_exec($ch); curl_close($ch); return json_decode($r,true) ?: [];
}
