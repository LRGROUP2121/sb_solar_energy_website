<?php
require_once __DIR__."/../config/database.php";
require_once __DIR__."/../bot/Bot.php";
$c=require __DIR__."/../config/config.php";
if($_SERVER["REQUEST_METHOD"]==="GET"){
 $token=$_GET["hub_verify_token"]??"";
 if(($_GET["hub_mode"]??"")==="subscribe" && hash_equals($c["whatsapp"]["verify_token"],$token)){
  echo $_GET["hub_challenge"]??""; exit;
 }
 http_response_code(403); exit("Verification failed");
}
if($_SERVER["REQUEST_METHOD"]!=="POST"){http_response_code(405);exit;}
$data=json_decode(file_get_contents("php://input"),true);
if($data) (new Bot($pdo))->process($data);
http_response_code(200); echo "EVENT_RECEIVED";
