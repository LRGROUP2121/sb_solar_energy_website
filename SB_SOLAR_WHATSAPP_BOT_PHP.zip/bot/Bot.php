<?php
require_once __DIR__."/../api/send-message.php";
class Bot{
 public function __construct(private PDO $db){}
 public function process($data){
  $m=$data["entry"][0]["changes"][0]["value"]["messages"][0]??null; if(!$m)return;
  $phone=$m["from"]??""; $text=trim($m["text"]["body"]??""); if(!$phone)return;
  $this->log($phone,"IN",$m["type"]??"unknown",$text);
  if(in_array(mb_strtolower($text),["hi","hello","hii","hey","नमस्ते","नमस्कार","start","menu"],true)){ $this->menu($phone);return; }
  $this->route($phone,$text);
 }
 private function route($p,$t){
  switch(mb_strtolower($t)){
   case "1": sendWhatsAppText($p,"☀️ SB SOLAR ENERGY PRICE LIST\n\n1 KW\n2 KW\n3 KW\n5 KW\n7 KW\n10 KW\n\nअपनी आवश्यकता का KW भेजें।");break;
   case "2": sendWhatsAppText($p,"💰 Government Subsidy\n\nअपना बिजली बिल भेजें या Solar KW बताएं।");break;
   case "3": $this->lead($p,"Installation");break;
   case "4": $this->complaint($p);break;
   case "5": $this->lead($p,"Quotation");break;
   case "6": sendWhatsAppText($p,"🏦 Loan / EMI enquiry के लिए अपना नाम, शहर और Solar KW भेजें।");break;
   case "7": sendWhatsAppText($p,"👨‍💼 Executive request दर्ज हो गई है। हमारी टीम जल्द संपर्क करेगी।");break;
   default: sendWhatsAppText($p,"कृपया 1 से 7 में विकल्प भेजें।\n\n1️⃣ Price List\n2️⃣ Subsidy\n3️⃣ Installation\n4️⃣ Service\n5️⃣ Quotation\n6️⃣ Loan / EMI\n7️⃣ Executive");
  }
 }
 private function menu($p){sendWhatsAppText($p,"☀️ SB SOLAR ENERGY\n\nनमस्कार! आपका स्वागत है।\n\n1️⃣ Solar Price List\n2️⃣ Government Subsidy\n3️⃣ Solar Installation\n4️⃣ Service / Complaint\n5️⃣ Quotation\n6️⃣ Loan / EMI\n7️⃣ Executive से बात करें");}
 private function lead($p,$type){
  $this->customer($p);
  $q=$this->db->prepare("INSERT INTO leads(customer_id,status,source,notes) VALUES((SELECT id FROM customers WHERE phone=?),'New','WhatsApp',?)");
  $q->execute([$p,$type]); sendWhatsAppText($p,"✅ आपकी {$type} enquiry दर्ज हो गई है।\n\nकृपया अपना नाम भेजें।");
 }
 private function complaint($p){
  $this->customer($p); $no="SB-".date("YmdHis")."-".random_int(100,999);
  $q=$this->db->prepare("INSERT INTO complaints(customer_id,complaint_no,complaint_type,description) VALUES((SELECT id FROM customers WHERE phone=?),?,'General Service','WhatsApp complaint')");
  $q->execute([$p,$no]); sendWhatsAppText($p,"🔧 Complaint registered.\n\nComplaint No: {$no}\n\nकृपया समस्या की जानकारी भेजें।");
 }
 private function customer($p){$q=$this->db->prepare("INSERT INTO customers(phone) VALUES(?) ON DUPLICATE KEY UPDATE phone=VALUES(phone)");$q->execute([$p]);}
 private function log($p,$d,$t,$m){$q=$this->db->prepare("INSERT INTO messages(phone,direction,message_type,message) VALUES(?,?,?,?)");$q->execute([$p,$d,$t,$m]);}
}
