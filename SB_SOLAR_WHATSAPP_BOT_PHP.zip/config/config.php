<?php
return [
  "db"=>[
    "host"=>getenv("DB_HOST") ?: "localhost",
    "name"=>getenv("DB_NAME") ?: "sb_whatsapp_bot",
    "user"=>getenv("DB_USER") ?: "root",
    "pass"=>getenv("DB_PASS") ?: ""
  ],
  "whatsapp"=>[
    "token"=>getenv("WHATSAPP_TOKEN") ?: "CHANGE_ME",
    "phone_number_id"=>getenv("WHATSAPP_PHONE_NUMBER_ID") ?: "CHANGE_ME",
    "api_version"=>getenv("WHATSAPP_API_VERSION") ?: "v23.0",
    "verify_token"=>getenv("WHATSAPP_VERIFY_TOKEN") ?: "SB_SOLAR_VERIFY_2026"
  ]
];
