<?php
$c=require __DIR__."/config.php"; $d=$c["db"];
try {
 $pdo=new PDO("mysql:host={$d["host"]};dbname={$d["name"]};charset=utf8mb4",$d["user"],$d["pass"],
 [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
} catch(PDOException $e){ http_response_code(500); exit("Database connection failed."); }
