# SB SOLAR ENERGY - PHP + MySQL Website & Support Portal

## Included
Home, About, Services, Products, Solar Calculator, Quote/Lead Form, AI Chatbot, Customer Login, Ticket System, Admin Panel, Technician Panel.

## Install
1. PHP 8.1+ with PDO MySQL and cURL.
2. Create/import the database using `database/schema.sql`.
3. Edit `config/config.php` with MySQL credentials.
4. Put the folder in Apache/Nginx web root.
5. Set `BASE_URL` to the actual URL.
6. Add an AI API key to `AI_API_KEY` for live AI replies.
7. Open the site in browser.

## Demo
Admin: admin@example.com / password
Technician: tech@example.com / password
Change these immediately on a production installation.

## Notes
- The calculator is an indicative estimate, not an engineering or financial guarantee.
- Keep AI keys server-side.
- Use HTTPS in production.
- Add rate limiting, backup, mail/WhatsApp notifications and upload validation before production use.
