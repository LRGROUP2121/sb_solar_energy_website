<?php
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
require_once __DIR__.'/db.php';
function e($x){return htmlspecialchars((string)$x,ENT_QUOTES,'UTF-8');}
function csrf(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function csrf_field(){return '<input type="hidden" name="csrf" value="'.e(csrf()).'">';}
function verify_csrf(){if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??''))die('Invalid request.');}
function current_user(){return $_SESSION['user']??null;}
function login_user($u){$_SESSION['user']=$u;}
function logout_user(){$_SESSION=[];session_destroy();}
function require_login(){if(!current_user()){header('Location: '.BASE_URL.'/login.php');exit;}}
function require_role($roles){require_login();if(!in_array(current_user()['role'],$roles,true)){http_response_code(403);exit('Forbidden');}}
