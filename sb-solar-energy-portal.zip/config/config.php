<?php
// SB SOLAR ENERGY PORTAL - configuration
define('APP_NAME','SB SOLAR ENERGY');
define('BASE_URL','http://localhost/sb-solar-energy-portal');

// MySQL
define('DB_HOST','localhost');
define('DB_NAME','sb_solar');
define('DB_USER','root');
define('DB_PASS','');

// AI (server-side only). Example OpenAI-compatible Chat Completions endpoint.
define('AI_API_URL','https://api.openai.com/v1/chat/completions');
define('AI_API_KEY','');
define('AI_MODEL','gpt-4o-mini');

// Business
define('BUSINESS_PHONE','9680204664');
define('BUSINESS_EMAIL','info@sbsolarenergy.in');
define('BUSINESS_CITY','Jaipur, Rajasthan');
