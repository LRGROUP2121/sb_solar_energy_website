CREATE DATABASE IF NOT EXISTS sb_solar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sb_solar;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,email VARCHAR(190) UNIQUE NOT NULL,phone VARCHAR(30),password_hash VARCHAR(255) NOT NULL,role ENUM('admin','technician','customer') DEFAULT 'customer',active TINYINT(1) DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE leads(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,phone VARCHAR(30) NOT NULL,email VARCHAR(190),city VARCHAR(120),monthly_bill DECIMAL(12,2),system_size VARCHAR(30),message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE tickets(id INT AUTO_INCREMENT PRIMARY KEY,customer_id INT NOT NULL,technician_id INT NULL,subject VARCHAR(255) NOT NULL,category VARCHAR(80),priority ENUM('Low','Medium','High','Critical') DEFAULT 'Medium',status ENUM('Open','In Progress','Waiting Customer','Resolved','Closed') DEFAULT 'Open',description TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,FOREIGN KEY(customer_id) REFERENCES users(id),FOREIGN KEY(technician_id) REFERENCES users(id) ON DELETE SET NULL);
CREATE TABLE ticket_messages(id INT AUTO_INCREMENT PRIMARY KEY,ticket_id INT NOT NULL,user_id INT NOT NULL,message TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE ai_conversations(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,role ENUM('user','assistant') NOT NULL,message TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
INSERT INTO users(name,email,password_hash,role) VALUES
('SB Admin','admin@example.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCqI2h7rJ0lZ6Lh3eK.','admin'),
('SB Technician','tech@example.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCqI2h7rJ0lZ6Lh3eK.','technician');
-- Seeded password for both accounts: password
